// Placeholder closest hit shader
