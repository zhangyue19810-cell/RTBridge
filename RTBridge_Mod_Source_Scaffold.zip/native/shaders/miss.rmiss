// Placeholder miss shader
