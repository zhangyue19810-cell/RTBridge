#pragma once
#include "scene_database.hpp"

namespace rtbridge {

class VulkanBackend {
public:
    bool initialize();
    void shutdown();
    void render(const SceneSnapshotNative& scene);
};

} // namespace rtbridge
