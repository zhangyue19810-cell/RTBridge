#pragma once

namespace rtbridge {

struct CompositeInputs {
    const void* openglColor = nullptr;
    const void* rtShadow = nullptr;
    const void* rtReflection = nullptr;
    const void* rtGI = nullptr;
    const void* motionVectors = nullptr;
    const void* depth = nullptr;
};

class CompositePass {
public:
    void composite(const CompositeInputs& inputs);
};

} // namespace rtbridge
