#pragma once
#include "scene_database.hpp"

namespace rtbridge {

class BvhBuilder {
public:
    void buildStaticGeometry(const SceneSnapshotNative& scene);
    void buildShipGeometryAsync(const SceneSnapshotNative& scene);
    void updateTransformOnly(const SceneSnapshotNative& scene);
};

} // namespace rtbridge
