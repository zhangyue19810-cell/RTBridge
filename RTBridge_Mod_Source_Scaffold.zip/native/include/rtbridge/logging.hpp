#pragma once
#include <string_view>

namespace rtbridge {
    void log(std::string_view msg);
}
