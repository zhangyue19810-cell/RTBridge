#pragma once
#include <cstdint>
#include <unordered_map>
#include <vector>
#include <string>

namespace rtbridge {

struct Transform {
    float m[16]{};
};

struct Material {
    float metallic = 0.0f;
    float roughness = 1.0f;
    float transparency = 0.0f;
    bool emissive = false;
    std::string albedo;
};

struct Light {
    uint64_t id = 0;
    float position[3]{};
    float color[3]{};
    float intensity = 0.0f;
    float radius = 0.0f;
};

struct Mesh {
    std::vector<float> vertices;
    std::vector<uint32_t> indices;
    Material material;
};

struct SceneSnapshotNative {
    std::unordered_map<uint64_t, Mesh> staticMeshes;
    std::unordered_map<uint64_t, Mesh> dynamicMeshes;
    std::unordered_map<uint64_t, Transform> shipTransforms;
    std::unordered_map<uint64_t, Light> emissiveLights;
};

class SceneDatabase {
public:
    void clear();
    SceneSnapshotNative& writable();
    const SceneSnapshotNative& readable() const;
    void publish();

private:
    SceneSnapshotNative front_;
    SceneSnapshotNative middle_;
    SceneSnapshotNative back_;
};

} // namespace rtbridge
