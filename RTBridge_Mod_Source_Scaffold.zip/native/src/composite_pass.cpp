#include "rtbridge/composite_pass.hpp"
#include "rtbridge/logging.hpp"

namespace rtbridge {

void CompositePass::composite(const CompositeInputs& inputs) {
    log("CompositePass::composite (placeholder)");
    (void)inputs;
}

} // namespace rtbridge
