#include "rtbridge/scene_database.hpp"

namespace rtbridge {

void SceneDatabase::clear() {
    back_ = SceneSnapshotNative{};
}

SceneSnapshotNative& SceneDatabase::writable() {
    return back_;
}

const SceneSnapshotNative& SceneDatabase::readable() const {
    return front_;
}

void SceneDatabase::publish() {
    middle_ = back_;
    front_ = middle_;
}

} // namespace rtbridge
