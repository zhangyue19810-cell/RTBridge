#include "rtbridge/logging.hpp"

namespace rtbridge {
void denoiser_stub() {
    log("denoiser_stub: placeholder");
}
}
