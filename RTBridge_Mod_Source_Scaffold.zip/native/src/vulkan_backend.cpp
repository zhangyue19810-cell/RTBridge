#include "rtbridge/vulkan_backend.hpp"
#include "rtbridge/logging.hpp"

namespace rtbridge {

bool VulkanBackend::initialize() {
    log("VulkanBackend::initialize (placeholder)");
    return true;
}

void VulkanBackend::shutdown() {
    log("VulkanBackend::shutdown (placeholder)");
}

void VulkanBackend::render(const SceneSnapshotNative& scene) {
    log("VulkanBackend::render (placeholder)");
    (void)scene;
}

} // namespace rtbridge
