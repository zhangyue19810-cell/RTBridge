#include "rtbridge/bvh_builder.hpp"
#include "rtbridge/logging.hpp"

namespace rtbridge {

void BvhBuilder::buildStaticGeometry(const SceneSnapshotNative& scene) {
    log("buildStaticGeometry: placeholder");
    (void)scene;
}

void BvhBuilder::buildShipGeometryAsync(const SceneSnapshotNative& scene) {
    log("buildShipGeometryAsync: placeholder async queue");
    (void)scene;
}

void BvhBuilder::updateTransformOnly(const SceneSnapshotNative& scene) {
    log("updateTransformOnly: TLAS instance transform refresh");
    (void)scene;
}

} // namespace rtbridge
