#include <jni.h>
#include "rtbridge/logging.hpp"
#include "rtbridge/scene_database.hpp"
#include "rtbridge/vulkan_backend.hpp"
#include "rtbridge/bvh_builder.hpp"
#include "rtbridge/composite_pass.hpp"

static rtbridge::SceneDatabase gScene;
static rtbridge::VulkanBackend gVulkan;
static rtbridge::BvhBuilder gBvh;
static rtbridge::CompositePass gComposite;

extern "C" {

JNIEXPORT void JNICALL Java_com_rtbridge_api_NativeBridge_initializeNative(JNIEnv*, jobject) {
    rtbridge::log("JNI initializeNative");
    gVulkan.initialize();
}

JNIEXPORT void JNICALL Java_com_rtbridge_api_NativeBridge_shutdownNative(JNIEnv*, jobject) {
    rtbridge::log("JNI shutdownNative");
    gVulkan.shutdown();
}

JNIEXPORT void JNICALL Java_com_rtbridge_api_NativeBridge_submitSceneNative(JNIEnv*, jobject, jobject /*snapshot*/, jfloat /*partialTick*/) {
    rtbridge::log("JNI submitSceneNative");
    gBvh.updateTransformOnly(gScene.readable());
    gVulkan.render(gScene.readable());

    rtbridge::CompositeInputs inputs;
    gComposite.composite(inputs);
}

} // extern "C"
