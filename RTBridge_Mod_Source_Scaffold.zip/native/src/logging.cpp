#include "rtbridge/logging.hpp"
#include <iostream>

namespace rtbridge {
    void log(std::string_view msg) {
        std::cout << "[RTBridge] " << msg << std::endl;
    }
}
