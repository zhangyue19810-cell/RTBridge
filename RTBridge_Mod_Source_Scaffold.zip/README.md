# RTBridge Mod Source (Scaffold)

This is a starter scaffold for the `RTBridge` architecture.

- OpenGL stays intact
- A separate Vulkan RT branch is added
- Scene extraction is event-driven
- Scene data is shared through a triple-buffered snapshot model
- Native C++ stubs are included for Vulkan / BVH / composite work

This is a scaffold, not a production-ready RT mod.
