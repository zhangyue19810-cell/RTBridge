package com.rtbridge.scene;

public record EmissiveLight(
        LightKey key,
        Vec3 position,
        Vec3 color,
        float intensity,
        float radius) {
}
