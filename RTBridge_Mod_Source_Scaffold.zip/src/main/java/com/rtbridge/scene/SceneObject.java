package com.rtbridge.scene;

public record SceneObject(GeometryData geometry, TransformData transform) {
    public static SceneObject empty() {
        return new SceneObject(GeometryData.empty(), TransformData.identity());
    }

    public SceneObject withGeometry(GeometryData newGeometry) {
        return new SceneObject(newGeometry, transform);
    }

    public SceneObject withTransform(TransformData newTransform) {
        return new SceneObject(geometry, newTransform);
    }
}
