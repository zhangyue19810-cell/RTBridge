package com.rtbridge.scene;

public record Vec3(float x, float y, float z) {
    public static Vec3 zero() {
        return new Vec3(0f, 0f, 0f);
    }
}
