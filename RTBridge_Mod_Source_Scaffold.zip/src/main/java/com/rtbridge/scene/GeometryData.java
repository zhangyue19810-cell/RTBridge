package com.rtbridge.scene;

import java.util.List;

public record GeometryData(
        List<Vertex> vertices,
        List<Integer> indices,
        MaterialData material) {

    public static GeometryData empty() {
        return new GeometryData(List.of(), List.of(), MaterialData.defaultMaterial());
    }
}
