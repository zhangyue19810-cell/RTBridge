package com.rtbridge.scene;

public record MaterialData(
        String albedoTexture,
        float metallic,
        float roughness,
        float transparency,
        boolean emissive) {

    public static MaterialData defaultMaterial() {
        return new MaterialData("", 0.0f, 1.0f, 0.0f, false);
    }
}
