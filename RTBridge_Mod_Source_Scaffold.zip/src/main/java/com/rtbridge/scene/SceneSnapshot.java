package com.rtbridge.scene;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public record SceneSnapshot(
        Map<ChunkKey, GeometryData> chunkGeometry,
        Map<BlockKey, GeometryData> blockEntityGeometry,
        Map<EntityKey, SceneObject> entities,
        Map<ShipKey, SceneObject> ships,
        Map<LightKey, EmissiveLight> emissives) {

    public static SceneSnapshot empty() {
        return new SceneSnapshot(
                Collections.emptyMap(),
                Collections.emptyMap(),
                Collections.emptyMap(),
                Collections.emptyMap(),
                Collections.emptyMap());
    }

    public SceneSnapshot copy() {
        return new SceneSnapshot(
                new LinkedHashMap<>(chunkGeometry),
                new LinkedHashMap<>(blockEntityGeometry),
                new LinkedHashMap<>(entities),
                new LinkedHashMap<>(ships),
                new LinkedHashMap<>(emissives));
    }

    public SceneSnapshot withChunkGeometry(ChunkKey key, GeometryData geometry) {
        var map = new LinkedHashMap<>(chunkGeometry);
        map.put(key, geometry);
        return new SceneSnapshot(map, blockEntityGeometry, entities, ships, emissives);
    }

    public SceneSnapshot withRemovedChunk(ChunkKey key) {
        var map = new LinkedHashMap<>(chunkGeometry);
        map.remove(key);
        return new SceneSnapshot(map, blockEntityGeometry, entities, ships, emissives);
    }

    public SceneSnapshot withBlockEntityGeometry(BlockKey key, GeometryData geometry) {
        var map = new LinkedHashMap<>(blockEntityGeometry);
        map.put(key, geometry);
        return new SceneSnapshot(chunkGeometry, map, entities, ships, emissives);
    }

    public SceneSnapshot withEntity(EntityKey key, GeometryData geometry, TransformData transform) {
        var map = new LinkedHashMap<>(entities);
        map.put(key, new SceneObject(geometry, transform));
        return new SceneSnapshot(chunkGeometry, blockEntityGeometry, map, ships, emissives);
    }

    public SceneSnapshot withShipMesh(ShipKey key, GeometryData geometry) {
        var map = new LinkedHashMap<>(ships);
        SceneObject old = map.getOrDefault(key, SceneObject.empty());
        map.put(key, old.withGeometry(geometry));
        return new SceneSnapshot(chunkGeometry, blockEntityGeometry, entities, map, emissives);
    }

    public SceneSnapshot withShipTransform(ShipKey key, TransformData transform) {
        var map = new LinkedHashMap<>(ships);
        SceneObject old = map.getOrDefault(key, SceneObject.empty());
        map.put(key, old.withTransform(transform));
        return new SceneSnapshot(chunkGeometry, blockEntityGeometry, entities, map, emissives);
    }

    public SceneSnapshot withEmissive(LightKey key, EmissiveLight light) {
        var map = new LinkedHashMap<>(emissives);
        map.put(key, light);
        return new SceneSnapshot(chunkGeometry, blockEntityGeometry, entities, ships, map);
    }
}
