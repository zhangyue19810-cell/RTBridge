package com.rtbridge.scene;

public record ChunkKey(int x, int z) { }
record BlockKey(int x, int y, int z) { }
record EntityKey(long id) { }
record ShipKey(long id) { }
record LightKey(long id) { }
