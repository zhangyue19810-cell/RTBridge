package com.rtbridge.scene;

import java.util.concurrent.locks.ReentrantReadWriteLock;

public final class SceneDatabase {
    private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();

    private SceneSnapshot front = SceneSnapshot.empty();
    private SceneSnapshot middle = SceneSnapshot.empty();
    private SceneSnapshot back = SceneSnapshot.empty();

    public void updateChunkGeometry(ChunkKey key, GeometryData geometry) {
        lock.writeLock().lock();
        try {
            back = back.withChunkGeometry(key, geometry);
        } finally {
            lock.writeLock().unlock();
        }
    }

    public void removeChunkGeometry(ChunkKey key) {
        lock.writeLock().lock();
        try {
            back = back.withRemovedChunk(key);
        } finally {
            lock.writeLock().unlock();
        }
    }

    public void updateBlockEntityGeometry(BlockKey key, GeometryData geometry) {
        lock.writeLock().lock();
        try {
            back = back.withBlockEntityGeometry(key, geometry);
        } finally {
            lock.writeLock().unlock();
        }
    }

    public void updateEntity(EntityKey key, GeometryData geometry, TransformData transform) {
        lock.writeLock().lock();
        try {
            back = back.withEntity(key, geometry, transform);
        } finally {
            lock.writeLock().unlock();
        }
    }

    public void updateShipMesh(ShipKey key, GeometryData geometry) {
        lock.writeLock().lock();
        try {
            back = back.withShipMesh(key, geometry);
        } finally {
            lock.writeLock().unlock();
        }
    }

    public void updateShipTransform(ShipKey key, TransformData transform) {
        lock.writeLock().lock();
        try {
            back = back.withShipTransform(key, transform);
        } finally {
            lock.writeLock().unlock();
        }
    }

    public void updateEmissive(LightKey key, EmissiveLight light) {
        lock.writeLock().lock();
        try {
            back = back.withEmissive(key, light);
        } finally {
            lock.writeLock().unlock();
        }
    }

    public void commitWriteSnapshot() {
        lock.writeLock().lock();
        try {
            middle = back.copy();
        } finally {
            lock.writeLock().unlock();
        }
    }

    public SceneSnapshot swapReadableSnapshot() {
        lock.writeLock().lock();
        try {
            SceneSnapshot previousFront = front;
            front = middle;
            middle = previousFront;
            return front;
        } finally {
            lock.writeLock().unlock();
        }
    }

    public SceneSnapshot currentFront() {
        lock.readLock().lock();
        try {
            return front;
        } finally {
            lock.readLock().unlock();
        }
    }
}
