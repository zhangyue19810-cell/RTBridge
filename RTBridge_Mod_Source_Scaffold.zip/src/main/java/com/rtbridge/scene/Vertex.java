package com.rtbridge.scene;

public record Vertex(
        float x, float y, float z,
        float nx, float ny, float nz,
        float u, float v) {
}
