package com.rtbridge.api;

import com.rtbridge.scene.SceneSnapshot;

public final class NativeBridge {
    private boolean loaded;

    public void tryLoad() {
        try {
            System.loadLibrary("rtbridge_native");
            loaded = true;
        } catch (Throwable t) {
            loaded = false;
            System.err.println("[RTBridge] Native library load failed: " + t.getMessage());
        }
    }

    public boolean isLoaded() {
        return loaded;
    }

    public native void initializeNative();
    public native void shutdownNative();
    public native void submitSceneNative(SceneSnapshot snapshot, float partialTick);

    public void initialize() {
        if (loaded) {
            try {
                initializeNative();
            } catch (UnsatisfiedLinkError e) {
                System.err.println("[RTBridge] initializeNative missing: " + e.getMessage());
            }
        }
    }

    public void submitFrame(SceneSnapshot snapshot, float partialTick) {
        if (loaded) {
            try {
                submitSceneNative(snapshot, partialTick);
            } catch (UnsatisfiedLinkError e) {
                System.err.println("[RTBridge] submitSceneNative missing: " + e.getMessage());
            }
        }
    }

    public void shutdown() {
        if (loaded) {
            try {
                shutdownNative();
            } catch (UnsatisfiedLinkError e) {
                System.err.println("[RTBridge] shutdownNative missing: " + e.getMessage());
            }
        }
    }
}
