package com.rtbridge.extract;

import com.rtbridge.scene.*;

import java.util.List;
import java.util.Map;

public final class SceneExtractor {
    private final SceneDatabase database;

    public SceneExtractor(SceneDatabase database) {
        this.database = database;
    }

    public void onChunkLoaded(ChunkKey key, GeometryData geometry) {
        database.updateChunkGeometry(key, geometry);
    }

    public void onChunkUnloaded(ChunkKey key) {
        database.removeChunkGeometry(key);
    }

    public void onBlockUpdated(BlockKey key, GeometryData geometry) {
        database.updateBlockEntityGeometry(key, geometry);
    }

    public void onEntityUpdated(EntityKey key, GeometryData geometry, TransformData transform) {
        database.updateEntity(key, geometry, transform);
    }

    public void onShipCreated(ShipKey key, GeometryData shipMesh, TransformData transform) {
        database.updateShipMesh(key, shipMesh);
        database.updateShipTransform(key, transform);
    }

    public void onShipMoved(ShipKey key, TransformData transform) {
        database.updateShipTransform(key, transform);
    }

    public void onLightUpdated(LightKey key, EmissiveLight light) {
        database.updateEmissive(key, light);
    }

    public void commitFrame() {
        database.commitWriteSnapshot();
    }

    public void extractFromWorldSnapshot(
            Map<ChunkKey, GeometryData> chunks,
            Map<BlockKey, GeometryData> blockEntities,
            Map<EntityKey, SceneObject> entities,
            Map<ShipKey, SceneObject> ships,
            List<EmissiveLight> lights) {

        chunks.forEach(database::updateChunkGeometry);
        blockEntities.forEach(database::updateBlockEntityGeometry);

        for (Map.Entry<EntityKey, SceneObject> entry : entities.entrySet()) {
            SceneObject obj = entry.getValue();
            database.updateEntity(entry.getKey(), obj.geometry(), obj.transform());
        }

        for (Map.Entry<ShipKey, SceneObject> entry : ships.entrySet()) {
            SceneObject obj = entry.getValue();
            database.updateShipMesh(entry.getKey(), obj.geometry());
            database.updateShipTransform(entry.getKey(), obj.transform());
        }

        for (EmissiveLight light : lights) {
            database.updateEmissive(light.key(), light);
        }

        database.commitWriteSnapshot();
    }
}
