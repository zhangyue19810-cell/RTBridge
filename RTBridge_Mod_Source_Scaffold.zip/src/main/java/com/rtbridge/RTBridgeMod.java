package com.rtbridge;

import com.rtbridge.api.NativeBridge;
import com.rtbridge.scene.SceneDatabase;
import com.rtbridge.scene.SceneSnapshot;
import com.rtbridge.extract.SceneExtractor;

public final class RTBridgeMod {
    public static final String MOD_ID = "rtbridge";

    private final SceneDatabase sceneDatabase = new SceneDatabase();
    private final SceneExtractor extractor = new SceneExtractor(sceneDatabase);
    private final NativeBridge nativeBridge = new NativeBridge();

    public RTBridgeMod() {
        nativeBridge.tryLoad();
        nativeBridge.initialize();
    }

    public SceneDatabase sceneDatabase() {
        return sceneDatabase;
    }

    public SceneExtractor extractor() {
        return extractor;
    }

    public void tickClientFrame(float partialTick) {
        SceneSnapshot snapshot = sceneDatabase.swapReadableSnapshot();
        nativeBridge.submitFrame(snapshot, partialTick);
    }
}
